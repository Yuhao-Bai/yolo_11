# Security Policy

## Supported Versions

In this project, we are only support latest code.

| Version | Supported          |
| ------- | ------------------ |
| latest   | :white_check_mark: |

## Reporting a Vulnerability

If you find any sequrity related problem, let us know by creating an issue about it.
