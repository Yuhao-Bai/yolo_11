Bipedal Planner
-----------------------------

Bipedal Walking with modifying designated footsteps

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/Bipedal/bipedal_planner/animation.gif
