Drone 3d trajectory following
-----------------------------

This is a 3d trajectory following simulation for a quadrotor.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/AerialNavigation/drone_3d_trajectory_following/animation.gif
